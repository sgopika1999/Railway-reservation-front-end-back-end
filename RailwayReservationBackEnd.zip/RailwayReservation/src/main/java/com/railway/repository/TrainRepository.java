package com.railway.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.railway.entity.Train;
import com.railway.entity.User;

@Repository
public interface TrainRepository  extends JpaRepository <Train,Long> {
//	@Query("select userId,userName,gender,date,phoneNo from User where train_Id is NULL")
//	public List<User> userTicketBooking();
//	

	@Query
	("select capacity,trainName from Train where train_id=:trainId")
public	Long findByCapacity(Long trainId);
	@Query
	("select capacity from Train where train_name=:trainName")
public	String findByTrainName(String trainName);
}
